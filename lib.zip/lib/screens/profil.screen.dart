import 'package:flutter/material.dart';

class ProfilPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          topBox,
        ],
      ),
    );
  }
}

Widget topBox = Container(
  padding: EdgeInsets.fromLTRB(0, 30, 0, 30),
  width: double.infinity,
  decoration: BoxDecoration(
    gradient: LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        Colors.blue[400],
        Colors.tealAccent[700],
      ],
    ),
  ),
  child: Column(
    children: [
      imageProfile,
      textProfile,
    ],
  ),
);

Widget imageProfile = Container(
  padding: EdgeInsets.all(4),
  height: 150,
  width: 150,
  decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(75),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.2),
        spreadRadius: 1,
        blurRadius: 5,
        offset: Offset(0, 3),
      ),
    ],
  ),
  child: ClipRRect(
    borderRadius: BorderRadius.circular(1000),
    child: Image.network(
        'http://dev.villanovaice.com/wp-content/uploads/2015/02/Elon-Musk-300x300.jpg'),
  ),
);

Widget textProfile = Container(
  margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
  child: Column(
    children: [
      Text(
        'Elon Musk',
        style: TextStyle(
          color: Colors.white,
          fontSize: 22,
          fontWeight: FontWeight.bold,
        ),
      ),
      SizedBox(height: 5),
      Text(
        'UI/UX Designer / Front End Developper',
        textAlign: TextAlign.center,
        style: TextStyle(
          color: Colors.white,
          fontSize: 17,
        ),
      ),
      SizedBox(height: 5),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.location_on,
            color: Colors.white,
          ),
          Text(
            'Los Angeles, USA',
            style: TextStyle(
              color: Colors.white,
              fontSize: 17,
            ),
          ),
        ],
      )
    ],
  ),
);
